nodes.csv
id: anonymized node id
rep: reputation score
t1-5: anonymized topic ids which users show interest in

links.csv
follower follows the followee. followee exerts influence upon the follower. 

Please reference to "F. G�rsoy and D. G�nne�, Influence Maximization in Social Networks under Deterministic Linear Threshold Model, ..., 2017." for details.

Please cite "F. G�rsoy and D. G�nne�, Influence Maximization in Social Networks under Deterministic Linear Threshold Model, ..., 2017."