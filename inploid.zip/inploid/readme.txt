nodes.csv
id: anonymized node id
rep: reputation score
t1-5: anonymized topic ids which users show interest in

links.csv
follower follows the followee. followee exerts influence upon the follower. 

Please refer to the published paper at https://doi.org/10.1016/j.knosys.2018.07.040 for details. 

Please cite:
Furkan Gursoy and Dilek Gunnec. Influence maximization in social networks under Deterministic Linear Threshold Model. Knowledge-Based Systems (2018). https://doi.org/10.1016/j.knosys.2018.07.040